Coloque aqui suas imagens de produto.
Substitua os placeholders do HTML por imagens reais usando <img src="assets/nome.jpg"> ou altere a div .img para background-image.
Sugestão de imagens:
- velvet.jpg
- lumina.jpg
- noir.jpg
- amber.jpg
- citrus.jpg
